$(document).ready(function(){

    function errortest()
    {
        setTimeout (function(){
        window.location.replace("todo.html"); 
        },1000);
    }

    $("#button").click(function(e){
        e.preventDefault();
        
    if ($("#username").val()==""|| $("#password").val()=="")
    { 
    document.getElementById("error").innerHTML= "**Username & Password are required**"
    }

     if ($("#username").val()=="admin" &&  $("#password").val()=="12345")
    {    
        access (errortest)
    }
  
    function access(callback)
    {
        alert("Login Completed Successfully.");
        callback()
    }

     })

})